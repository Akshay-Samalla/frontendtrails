import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  Typography,
  List,
  ListItem,
  ListItemText,
  Box,
  Divider,
} from "@mui/material";

// Sample data for tours
const toursData = [
  {
    tourname: "Pondicherry Adventure",
    tourid: "00001",
    included: [
      "Travelling expenses",
      "Accommodation",
      "Trip host",
      "Pre-hired tempo",
      "First aid",
    ],
    rating: 9,
    cost: 29999,
    location: "Pondicherry",
    timespent: "3 days",
    starting_date: "30-01-2020",
    starting_time: "7:00 am",
    return_time: "9:00 pm",
    stops: [
      {
        day1: [
          {
            loc: "Tambaram",
            notes: "Tambaram is a southern suburb of Chennai.",
            image:
              "https://swadeshitraveller.com/static/images/place/pondicherry/0054b772.jpg",
            pros: ["train", "beach", "breakfast"],
            duration: "5 hrs",
          },
          {
            loc: "Mahabalipuram",
            notes: "A UNESCO World Heritage site.",
            image: "https://source.unsplash.com/1600x900/?mahabalipuram",
            pros: ["temple", "ancient ruins", "seafood"],
            duration: "3 hrs",
          },
        ],
      },
      {
        day2: [
          {
            loc: "Auroville",
            notes: "An experimental township promoting unity.",
            image: "https://source.unsplash.com/1600x900/?auroville",
            pros: ["meditation", "nature", "cafes"],
            duration: "4 hrs",
          },
          {
            loc: "Pondicherry Beach",
            notes: "A beautiful beach with golden sand.",
            image: "https://source.unsplash.com/1600x900/?pondicherry,beach",
            pros: ["beach", "water sports", "sunset"],
            duration: "6 hrs",
          },
        ],
      },
    ],
  },
  {
    tourname: "Goa Getaway",
    tourid: "00002",
    included: [
      "Flight tickets",
      "Accommodation",
      "Tour guide",
      "Local transport",
      "Meals",
    ],
    rating: 8,
    cost: 34999,
    location: "Goa",
    timespent: "5 days",
    starting_date: "15-02-2020",
    starting_time: "9:00 am",
    return_time: "8:00 pm",
    stops: [
      {
        day1: [
          {
            loc: "Calangute Beach",
            notes: "One of the largest and most popular beaches.",
            image: "https://source.unsplash.com/1600x900/?calangute,beach",
            pros: ["beach", "water sports", "nightlife"],
            duration: "6 hrs",
          },
          {
            loc: "Baga Beach",
            notes: "Known for vibrant nightlife.",
            image: "https://source.unsplash.com/1600x900/?baga,beach",
            pros: ["nightlife", "water sports", "restaurants"],
            duration: "4 hrs",
          },
        ],
      },
      {
        day2: [
          {
            loc: "Dudhsagar Falls",
            notes: "A four-tiered waterfall located on the Mandovi River.",
            image: "https://source.unsplash.com/1600x900/?dudhsagar,falls",
            pros: ["waterfall", "trekking", "nature"],
            duration: "5 hrs",
          },
          {
            loc: "Old Goa",
            notes: "Famous for historic churches.",
            image: "https://source.unsplash.com/1600x900/?old goa,church",
            pros: ["history", "architecture", "culture"],
            duration: "3 hrs",
          },
        ],
      },
    ],
  },
];

// Sample data for coordinators
const coordinatorsData = [
  {
    username: "jhonne",
    email: "john.doe@example.com",
    guide_id: "guide0111",
    tours: { assignedTour: ["00001"] },
  },
];

// Sample booking data for travelers
const bookingsData = [
  {
    username: "joey",
    count: 90,
    phone: "9900909000",
    tourid: "00001",
    email: "joey@gmail.com",
  },
];

const CoordinatorPage = () => {
  const navigate = useNavigate();
  const [coordinators, setCoordinators] = useState([]);
  const [tours, setTours] = useState([]);
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    // Normally, you'd fetch this data from an API
    setCoordinators(coordinatorsData);
    setTours(toursData);
    setBookings(bookingsData);
  }, []);

  const findTourById = (tourId) => {
    return tours.find((tour) => tour.tourid === tourId);
  };

  const findBookingsByTourId = (tourId) => {
    return bookings.filter((booking) => booking.tourid === tourId);
  };

  return (
    <Box sx={{ padding: 4 }}>
      <Typography variant="h4" gutterBottom textAlign="center" color="primary">
        Coordinators & Their Tours
      </Typography>

      {coordinators.map((coordinator) => (
        <Card key={coordinator.guide_id} sx={{ marginBottom: 4, boxShadow: 3 }}>
          <CardContent>
            <Typography variant="h5" gutterBottom color="primary">
              Coordinator: {coordinator.username}
            </Typography>
            <Typography variant="body1" gutterBottom>
              Email: {coordinator.email}
            </Typography>
            <Divider />
            <Typography variant="h6" color="primary" sx={{ marginTop: 2 }}>
              Assigned Tours:
            </Typography>

            {coordinator.tours.assignedTour.map((tourId) => {
              const tour = findTourById(tourId);
              return tour ? (
                <Box key={tour.tourid} sx={{ marginBottom: 4 }}>
                  <Typography variant="h6" gutterBottom color="textSecondary">
                    Tour: {tour.tourname} ({tour.location})
                  </Typography>
                  <Typography variant="body2" gutterBottom>
                    Rating: {tour.rating}/10 | Cost: ₹{tour.cost} | Duration:{" "}
                    {tour.timespent}
                  </Typography>
                  <Typography variant="h6" gutterBottom color="textSecondary">
                    Start: ({tour.starting_date})
                  </Typography>
                  <Typography variant="h6" gutterBottom color="textSecondary">
                    Time: ({tour.starting_time})
                  </Typography>
                  <Typography variant="h6" gutterBottom color="textSecondary">
                    Return: ({tour.return_time})
                  </Typography>
                  <button
                    onClick={() => navigate(`/booking?tourid=${tour.tourid}`)}
                  >
                    TourId: ({tour.tourid})
                  </button>
                  <List>
                    {tour.included.map((item, index) => (
                      <ListItem key={index}>
                        <ListItemText primary={item} />
                      </ListItem>
                    ))}
                  </List>

                  {/* Traveler Details */}
                  <Typography
                    variant="h6"
                    color="primary"
                    sx={{ marginTop: 2 }}
                  >
                    Traveler Bookings:
                  </Typography>
                  {findBookingsByTourId(tourId).length === 0 ? (
                    <Typography variant="body1" color="textSecondary">
                      No bookings for this tour.
                    </Typography>
                  ) : (
                    findBookingsByTourId(tourId).map((booking) => (
                      <Box
                        key={booking.username + booking.tourid}
                        sx={{
                          marginBottom: 2,
                          padding: 1,
                          border: "1px solid #ccc",
                          borderRadius: 1,
                        }}
                      >
                        <Typography variant="body1">
                          Name: {booking.username} | Email: {booking.email} |
                          Phone: {booking.phone} | Count: {booking.count}
                        </Typography>
                      </Box>
                    ))
                  )}
                </Box>
              ) : (
                <Typography key={tourId} variant="body1" color="error">
                  No tour found for ID: {tourId}
                </Typography>
              );
            })}
          </CardContent>
        </Card>
      ))}
    </Box>
  );
};

export default CoordinatorPage;
