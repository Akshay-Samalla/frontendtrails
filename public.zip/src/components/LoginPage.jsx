import React, { useState } from "react";

const LoginPage = () => {
  const [isSignup, setIsSignup] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    usertype: isSignup ? "user" : "", // Default to 'user' for login
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const validateForm = () => {
    if (isSignup && formData.password !== formData.confirmPassword) {
      alert("Passwords do not match!");
      return false;
    }
    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    // Handle form submission (add your logic here)
    console.log(formData);
  };

  return (
    <div style={styles.background}>
      <video autoPlay loop muted style={styles.backgroundVideo}>
        <source
          src="https://videos.pexels.com/video-files/8318649/8318649-uhd_2560_1440_25fps.mp4"
          type="video/mp4"
        />
        Your browser does not support the video tag.
      </video>
      <div style={styles.container}>
        <div style={styles.card}>
          <h2 style={styles.title}>{isSignup ? "Sign Up" : "Sign In"}</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="username"
              placeholder="Username"
              onChange={handleChange}
              required
              style={styles.input}
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              onChange={handleChange}
              required
              style={styles.input}
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              onChange={handleChange}
              required
              style={styles.input}
            />
            {isSignup && (
              <input
                type="password"
                name="confirmPassword"
                placeholder="Confirm Password"
                onChange={handleChange}
                required
                style={styles.input}
              />
            )}
            {!isSignup && ( // Show usertype only in signup
              <select
                name="usertype"
                value={formData.usertype}
                onChange={handleChange}
                required
                style={styles.input}
              >
                <option value="user">User</option>
                <option value="admin">Admin</option>
                <option value="guide">Guide</option>
              </select>
            )}
            <div style={styles.buttonContainer}>
              <button type="submit" style={styles.button}>
                {isSignup ? "Sign Up" : "Sign In"}
              </button>
            </div>
            <div style={styles.footer}>
              <span style={styles.footerText}>
                {isSignup ? "Already have an account?" : "New user?"}{" "}
                <button
                  type="button"
                  onClick={() => setIsSignup(!isSignup)}
                  style={styles.toggleButton}
                >
                  {isSignup ? "Sign In" : "Sign Up"}
                </button>
              </span>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

const styles = {
  background: {
    position: "relative",
    height: "100vh",
    overflow: "hidden",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "column",
  },
  backgroundVideo: {
    position: "absolute",
    top: 0,
    left: 0,
    minWidth: "100%",
    minHeight: "100%",
    zIndex: -1,
    objectFit: "cover",
  },
  container: {
    zIndex: 1,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "column",
    padding: "20px",
    backgroundColor: "rgba(255, 255, 255, 0.9)",
    borderRadius: "8px",
    boxShadow: "0 4px 20px rgba(0, 0, 0, 0.2)",
  },
  card: {
    maxWidth: "400px",
    width: "100%",
    padding: "20px",
  },
  title: {
    textAlign: "center",
    marginBottom: "20px",
  },
  input: {
    width: "100%",
    padding: "10px",
    margin: "10px 0",
    borderRadius: "5px",
    border: "1px solid #ccc",
    fontSize: "16px",
  },
  buttonContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  button: {
    backgroundColor: "#007bff",
    color: "#fff",
    border: "none",
    padding: "10px 15px",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "16px",
  },
  footer: {
    textAlign: "center",
    marginTop: "20px",
  },
  footerText: {
    fontSize: "14px",
  },
  toggleButton: {
    backgroundColor: "transparent",
    color: "#007bff",
    border: "none",
    cursor: "pointer",
    fontSize: "14px",
  },
};

export default LoginPage;
