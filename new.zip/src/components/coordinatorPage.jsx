import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  Typography,
  List,
  ListItem,
  ListItemText,
  Box,
  Divider,
} from "@mui/material";

const CoordinatorPage = () => {
  const navigate = useNavigate();
  const [coordinators, setCoordinators] = useState([]);
  const [tours, setTours] = useState([]);
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    const token = localStorage.getItem("token");

    const fetchData = async () => {
      try {
        const coordinatorResponse = await fetch(
          `http://localhost:3001/guide/guide/${user.username}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const coordinatorsData = await coordinatorResponse.json();
        setCoordinators(coordinatorsData || []); // Default to empty array if undefined

        const toursResponse = await fetch(
          `http://localhost:3001/guide/tour/${user.username}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const toursData = await toursResponse.json();
        setTours(toursData?.map((tour) => tour.details) || []); // Default to empty array if undefined

        const bookingsResponse = await fetch(
          `http://localhost:3001/guide/travellers/${user.username}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const bookingsData = await bookingsResponse.json();
        console.log(bookingsData)
        setBookings(bookingsData || []); // Default to empty array if undefined
      } catch (err) {
        console.error("Error fetching data:", err);
      }
    };

    fetchData();
  }, []);

  const findTourById = (tourId) => {
    return tours.find((tour) => tour.tourid === tourId);
  };

  const findBookingsByTourId = (tourId) => {
    return bookings.filter((booking) => booking.tour_id === tourId);
  };

  return (
    <Box sx={{ padding: 4 }}>
      <Typography variant="h4" gutterBottom textAlign="center" color="primary">
        Coordinators & Their Tours
      </Typography>

      {coordinators.length > 0 ? (
        coordinators.map((coordinator) => (
          <Card
            key={coordinator.guide_id}
            sx={{ marginBottom: 4, boxShadow: 3 }}
          >
            <CardContent>
              <Typography variant="h5" gutterBottom color="primary">
                Coordinator: {coordinator.username}
              </Typography>
              <Typography variant="body1" gutterBottom>
                Email: {coordinator.email}
              </Typography>
              <Divider />
              <Typography variant="h6" color="primary" sx={{ marginTop: 2 }}>
                Assigned Tours:
              </Typography>

              {coordinator.tours?.assigned_tours?.length > 0 ? (
                coordinator.tours.assigned_tours.map((tourId) => {
                  const tour = findTourById(tourId);
                  console.log(tourId)

                  return tour ? (
                    <Box key={tour.tourid} sx={{ marginBottom: 4 }}>
                      <Typography
                        variant="h6"
                        gutterBottom
                        color="textSecondary"
                      >
                        Tour: {tour.tourname} ({tour.location})
                      </Typography>
                      <Typography variant="body2" gutterBottom>
                        Rating: {tour.rating}/10 | Cost: ₹{tour.cost} |
                        Duration: {tour.timespent}
                      </Typography>
                      <Typography
                        variant="h6"
                        gutterBottom
                        color="textSecondary"
                      >
                        Start: ({tour.starting_date})
                      </Typography>
                      <Typography
                        variant="h6"
                        gutterBottom
                        color="textSecondary"
                      >
                        Time: ({tour.starting_time})
                      </Typography>
                      <Typography
                        variant="h6"
                        gutterBottom
                        color="textSecondary"
                      >
                        Return: ({tour.return_time})
                      </Typography>
                      <button
                        onClick={() =>
                          navigate(`/booking?tourid=${tour.tourid}`)
                        }
                      >
                        TourId: ({tour.tourid})
                      </button>
                      <List>
                        {tour.included.map((item, index) => (
                          <ListItem key={index}>
                            <ListItemText primary={item} />
                          </ListItem>
                        ))}
                      </List>

                      {/* Traveler Details */}
                      <Typography
                        variant="h6"
                        color="primary"
                        sx={{ marginTop: 2 }}
                      >
                        Traveler Bookings:
                      </Typography>
                      {findBookingsByTourId(tourId).length === 0 ? (
                        <Typography variant="body1" color="textSecondary">
                          No bookings available.
                        </Typography>
                      ) : (
                        findBookingsByTourId(tourId).map((booking, index) => (
                          <Box key={index} sx={{ padding: 2 }}>
                            <Typography variant="body1">
                              Traveler: {booking.username} ({booking.email})
                            </Typography>
                            <Typography variant="body2">
                              Phone: {booking.phone} | Total Travelers:{" "}
                              {booking.count}
                            </Typography>
                          </Box>
                        ))
                      )}
                    </Box>
                  ) : (
                    <Typography key={tourId} variant="body1" color="error">
                      No tour found for this ID.
                    </Typography>
                  );
                })
              ) : (
                <Typography variant="body1" color="textSecondary">
                  No assigned tours.
                </Typography>
              )}
            </CardContent>
          </Card>
        ))
      ) : (
        <Typography variant="body1" color="textSecondary">
          No coordinators available.
        </Typography>
      )}
    </Box>
  );
};

export default CoordinatorPage;
