// src/components/TourPage.jsx
import React from "react";

const TourPage = () => {
  return (
    <div>
      <h1>Tour Page</h1>
      {/* Display tour details */}
    </div>
  );
};

export default TourPage;
