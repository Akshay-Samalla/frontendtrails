import React from "react";
import { AppBar, Toolbar, Typography, Button, Box } from "@mui/material";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <AppBar
      position="sticky" // Make navbar fixed to the top
      sx={{
        backgroundColor: "rgba(211, 211, 211, 0.5)", // Semi-transparent white
        backdropFilter: "blur(10px)", // Blur effect for professional look
        boxShadow: "none", // Remove default shadow
        width: "100%",
      }}
    >
      <Toolbar>
        {/* Logo with a professional gradient text */}
        <Typography
          variant="h6"
          component="div"
          sx={{
            flexGrow: 1,
            fontWeight: "bold",
            fontSize: "40px",
            background: "linear-gradient(60deg, #5b247a,#1bcedf)", // Gradient color
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent", // Make the text transparent to show the gradient
            textShadow: "2px 2px 4px rgba(0, 0, 0, 0.3)", // Subtle shadow for more contrast
          }}
        >
          Gradious Travels
        </Typography>
        <Box>
          {/* Navigation Links with hover effect */}
          <Button
            sx={{
              color: "white", // White inside
              textShadow: "2px 2px 4px rgba(0, 0, 0, 0.8)", // Black shadow effect
              fontWeight: "bold",
              transition: "color 0.3s, text-shadow 0.3s", // Smooth transition
              "&:hover": {
                background: "linear-gradient(90deg, #ff4b2b, #ff416c)",
                color: "black",
              },
            }}
            component={Link}
            to="/"
          >
            Home
          </Button>
          <Button
            sx={{
              color: "white",
              textShadow: "2px 2px 4px rgba(0, 0, 0, 0.8)",
              fontWeight: "bold",
              transition: "color 0.3s, text-shadow 0.3s",
              "&:hover": {
                color: "black",
                background: "linear-gradient(90deg, #ff4b2b, #ff416c)",
              },
            }}
            component={Link}
            to="/about"
          >
            About
          </Button>
          <Button
            sx={{
              color: "white",
              textShadow: "2px 2px 4px rgba(0, 0, 0, 0.8)",
              fontWeight: "bold",
              transition: "color 0.3s, text-shadow 0.3s",
              "&:hover": {
                color: "black",
                background: "linear-gradient(90deg, #ff4b2b, #ff416c)",
              },
            }}
            component={Link}
            to="/contact"
          >
            Contact
          </Button>
          <Button
            sx={{
              color: "white",
              textShadow: "2px 2px 4px rgba(0, 0, 0, 0.8)",
              fontWeight: "bold",
              transition: "color 0.3s, text-shadow 0.3s",
              "&:hover": {
                color: "black",
                background: "linear-gradient(90deg, #ff4b2b, #ff416c)",
              },
            }}
            component={Link}
            to="/login"
          >
            Login / Signup
          </Button>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
